<?php
/**
 * Page template override for cloudsales.ro.
 *
 * The parent theme's page.php is meant for short legal pages and caps the content at 820px.
 * cloudsales.ro pages are full-width block layouts (and the homepage is built in Elementor),
 * so here they get the site's normal width (.wrap, 1160px like bocp.ro). The front page prints
 * its content only: its headings live inside the content, so no extra title or breadcrumbs.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();

	if ( is_front_page() ) {
		the_content();
		continue;
	}
	?>
	<section class="section">
		<div class="wrap">
			<?php bocp_the_breadcrumbs(); ?>
			<h1 class="h-display"><?php the_title(); ?></h1>
			<div class="entry-content" style="margin-top:24px">
				<?php the_content(); ?>
			</div>
		</div>
	</section>
	<?php
endwhile;

get_footer();
